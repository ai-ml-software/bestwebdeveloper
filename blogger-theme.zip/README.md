# Best Web Developer — Blogger Theme

A Blogger (Blogspot) custom theme rebuilt from the bestwebdeveloper.org design system: Bootstrap 5, Sora/Inter typography, orange (#ff8c00) and gray (#1f2530) brand colors, floating geometric shapes, animated counters, hover overlays, and an SEO/GEO-first structure.

Use this only for a site whose design, text, and images you own or have permission to use.

## What's included

- `theme.xml` — the complete theme (upload this to Blogger)
- All homepage sections from the original layout, in the same order:
  1. Sticky navbar with Services dropdown + Free Consultation button
  2. Hero with gradient headline, floating chips, geometric motion, and live counters
  3. Services grid (12 cards with hover lift + icon animation)
  4. Why Clients Choose Us (image + 98% badge + checklist)
  5. Dark counters band (Projects / Clients / SEO Pages / Response)
  6. Process (Discover → Design → Develop → Grow)
  7. Filterable portfolio with hover overlays (All / Web / SEO / Marketing / Ecommerce)
  8. Testimonials (star cards)
  9. Latest insights — pulled dynamically from your real Blogger posts
  10. FAQ accordion
  11. Orange CTA banner
  12. Footer (4 columns, social icons, contact info) + WhatsApp float button
- Dynamic Blogger views: label/archive/search grid with pagination, single post layout with hero header, labels, share buttons, newer/older navigation, and threaded comments.

## Install

1. Blogger Dashboard → **Theme** → arrow next to Customize → **Restore** → upload `theme.xml`.
   (Or Edit HTML → select all → paste the file contents → Save.)
2. Publish at least 3 posts with a featured image and one label each (e.g. SEO, GEO, Web Design) — they fill the "Latest insights" cards automatically.
3. Create these static Pages so the menu links work (the URL slug must match):
   - about, portfolio, pricing, faq, contact, testimonials
   - Service pages: seo-services, web-design, web-development, ui-ux-design, digital-marketing, social-media, ppc-google-ads, youtube-marketing, wordpress-development, ecommerce-development, email-marketing, content-marketing, branding, android-app-development
   - Legal: privacy-policy, terms-conditions, cookie-policy
   Tip: Blogger creates the slug from the page title on first publish — title the page "About" and it becomes `/p/about.html`.

## Customize

- **Brand colors**: Theme → Customize → Advanced → the skin exposes Blogger variables (Primary Orange, Dark Gray Ink, etc.), or edit the `:root` block in the CSS.
- **Counters**: change `data-target` values in the hero and counters section.
- **WhatsApp**: replace the number in the `.wa-float` link and in the share bar.
- **Images**: swap the `src` URLs with your own uploads (Blogger post editor or any host). Keep descriptive `alt` text for SEO.
- **Menu**: nav links are hard-coded in the navbar block for full design control — edit them in Theme → Edit HTML.
- **Schema**: update the Organization JSON-LD block near the end of the file with your own address, phone, and social profiles.

## Notes

- Bootstrap 5.3, Bootstrap Icons, and Google Fonts load from CDNs.
- `prefers-reduced-motion` is respected (animations disabled for those users).
- The Blog1 widget is locked so the layout can't be accidentally deleted from the Layout tab.
